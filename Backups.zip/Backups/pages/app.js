App({
  onLaunch(){
    wx.cloud.init({
      env:'tan-ran-mian-dui-6f6bupycd7c158e'//云开发环境id
    })
  }
})
