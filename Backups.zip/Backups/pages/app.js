App({
  globalData: {
    user: ""
  },


  onLaunch() {
    wx.cloud.init({
      env: 'tan-ran-mian-dui-6f6bupycd7c158e' //云开发环境id
    })
  },
  onPullDownRefresh: function () {
    this.onRefresh();
  },

  onRefresh: function () {
    //导航条加载动画
    wx.showNavigationBarLoading();
    wx.showLoading({
      title: 'Loading...',
    })
    console.log("下拉刷新啦");
    setTimeout(function () {

      wx.hideNavigationBarLoading();
      //停止下拉刷新
      wx.stopPullDownRefresh();
    }, 2000);
  },
  onReachBottom: function () {
    //上拉加载
    wx.showLoading({
      title: '正在加载',
    })
    setTimeout(() => {
      wx.hideLoading()
    }, 1000)
  }
})