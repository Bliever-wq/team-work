let page 
Page({
  data: {
    article: [],
  },
  onLoad() {
    page = 0
    wx.cloud.database().collection('article').limit(5)
      .skip(page)
      .get()
      .then(res => {
        console.log("添加成功")
        this.setData({
          article: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  onReachBottom(){
    page++
    wx.cloud.database().collection('article').limit(5)
      .skip(page*5)
      .get()
      .then(res => {
        this.setData({
          article:this.data.article.concat(res.data) 
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  f1: function (event) {
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_3 = event.currentTarget.dataset.id_3
    var id_4 = event.currentTarget.dataset.id_4
    var id_5 = event.currentTarget.dataset.id_5
    var id_6 = event.currentTarget.dataset.id_6
    var id = event.currentTarget.dataset.id
   
    wx.cloud.database().collection('history')//判断是否在历史记录里面
    .where({
        id:id
      })
      .get()
      .then(res=>{
        if(res.data != 0){
          wx.cloud.database().collection('history')//更新历史记录
          .where({
            id:id
          })
          .update({
            data:{
              timeStamp: parseInt(Date.parse(new Date())),//时间戳
            }
          })
      } else{
         //只要有点击且历史记录里面没有就添加进历史记录
    wx.cloud.database().collection('history')
    .add({
      data:{
        id:id,
        level:id_1, 
        ming:id_2,
        skill:id_3,
        imagepath:id_4,
        name:id_5,
        location:id_6,
        timeStamp:parseInt(Date.parse(new Date())),//时间戳
      }
    })
      }
      })

    wx.navigateTo({
      url: "/article/article?id=" + id + "&id_1=" + id_1 + "&id_2=" + id_2 + "&id_3=" + id_3 + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6,
    })
  }
})