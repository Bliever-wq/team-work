let page = 0
var app = getApp();
Page({
  data: {
    article: [],
  },
  onLoad() {
    page = 0
    wx.cloud.database().collection('article').limit(5)
      .skip(page)
      .get()
      .then(res => {
        this.setData({
          article: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  onReachBottom() {
    page++
    wx.cloud.database().collection('article').limit(5)
      .skip(page * 5)
      .get()
      .then(res => {
        this.setData({
          article: this.data.article.concat(res.data)
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  f1: function (event) {
    var id = event.currentTarget.dataset.id
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_3 = event.currentTarget.dataset.id_3
    wx.cloud.database().collection('history') //判断是否在历史记录里面
      .where({
        Nickname: app.globalData.user.Nickname,
        id: id
      })
      .get()
      .then(res => {
        if (res.data != 0) {
          wx.cloud.database().collection('history') //更新历史记录
            .where({
              Nickname: app.globalData.user.Nickname,
              name:id_1,
              location:id_2,
              imagepath:id_3,
              id: id
            })
            .update({
              data: {
                timeStamp: parseInt(Date.parse(new Date())), //时间戳
              }
            })
        } else {
          //只要有点击且历史记录里面没有就添加进历史记录
          wx.cloud.database().collection('history')
            .add({
              data: {
                Nickname: app.globalData.user.Nickname,
                name:id_1,
                location:id_2,
                imagepath:id_3,
                id: id,
                timeStamp: parseInt(Date.parse(new Date())), //时间戳
              }
            })
        }
      })
    wx.navigateTo({
      url: "/article/article?id=" + id,
    })
  }
})