Page({
  ok() {
    wx.showToast({
      title: '提交成功'
    })
  }
})