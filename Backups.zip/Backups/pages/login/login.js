var app = getApp();
Page({
  data:{
    Nickname: '',
    password: '',
    open: false
  },
  //获取用户的手机号
  getPhone(e){
    this.setData({
      Nickname: e.detail.value
    })
  },

  //获取用户的密码
  getPsw(e){
    this.setData({
      password: e.detail.value
    })
  },

  //点击了登录
  login(){
     let Nickname = this.data.Nickname
     let password = this.data.password

     if(!Nickname){
      wx.showToast({
        title: '请输入名称',
        icon:'error',
      })
      return
    }
     
     if(!password){
      wx.showToast({
        title: '请输入密码',
        icon:'error',
      })
      return
    }

     console.log('password =',password)
     wx.cloud.database().collection('user')
      .where({
        Nickname,
        password
      }).get().then(res=>{
        console.log('登录的结果',res)
        if(res.data && res.data.length){ 
          getApp().globalData.user=res.data[0]
         wx.setStorageSync('user', res.data[0])
          wx.showToast({
            title: '登录成功',
          })
          setTimeout(()=>{
            wx.switchTab({
              url: '/me/me',
            })
          },1000)
        }else{
          wx.showToast({
            title: '账号或密码错误',
            icon:'error'
          })
        }
      })
  },

  //去注册页
  register(){
    wx.navigateTo({
      url: '/register/register',
    })
  }
})