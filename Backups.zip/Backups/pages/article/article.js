let shoucang = false
Page({
  data: {
    circular: true, 
    color1:'#1691f5',
    imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
    currentData: 0,
    curring: -1,
    image2:'',
    image3:'',
    wordlist:[
    {word:'',},
    {word:'',},
    {word:'',},
    {word:'',},
    {word:'',},
    {word:'',},
    {word:'',},
    ],
    detail: [{
        id: '1',
        title:'',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '2',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '3',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
      {
        id: '4',
        title: '',
        answer: '',
        array: [{
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
          {
            name: '',
            usname: false
          }, {
            name: '',
            usname: false
          },
        ]
      },
    ],
    number: 0,
    answer: 0,
  },
checkCurrent1: function (e) {
  this.setData({color1:'#1691f5'});
  circular:true;
  const that = this;
  if (that.data.currentData === e.target.dataset.current) {
    return false;
  } else {
    that.setData({
      currentData: e.target.dataset.current
    })
  }
},
checkCurrent2: function (e) {
  this.setData({color1:'#FF8247'});
  circular:true;
  const that = this;
  if (that.data.currentData === e.target.dataset.current) {
    return false;
  } else {
    that.setData({
      currentData: e.target.dataset.current
    })
  }
},
checkCurrent3: function (e) {
  this.setData({color1:'rgb(149, 0, 248)'});
  circular:true;
  const that = this;
  if (that.data.currentData === e.target.dataset.current) {
    return false;
  } else {
    that.setData({
      currentData: e.target.dataset.current
    })
  }
},
// // 加入书架
// chooseAddBookrack: function() {
//     let value = this.data.addBookrackSucceed;
//     wx.showToast({
//       title: '已收藏',      //标题
//       icon: "success",        //图标类型, 默认success
//       duration: 1500                //提示框停留时间, 默认1500ms
//     })
//     this.setData({
//       addBookrackSucceed: !value
//     })
//     console.log(value)
// },
// cancelAddBookrack: function() {
//   let value = this.data.addBookrackSucceed;
//   wx.showToast({
//     title: '已取消',      //标题
//     icon: "success",        //图标类型, 默认success
//     duration: 1500                //提示框停留时间, 默认1500ms
//   })
//   this.setData({
//     addBookrackSucceed: !value
//   })
//   console.log(value)
// },


onLoad: function (options) {
  this.setData({
    mid1: options.id_1,
    mid2: options.id_2,
    mid3: options.id_3,
    mid4: options.id_4,
    mid5: options.id_5,
    mid6: options.id_6,
    mid: options.id,
    imageurl: "",
  })
  wx.cloud.database().collection('shoucang') //判断是否在收藏里面
    .where({
      id: this.data.mid
    })
    .get()
    .then(res => {
      if (res.data != 0) {
        shoucang = true
        console.log("shoucang请求成功", res)
        this.setData({
          imageurl: "https://7461-tan-ran-mian-dui-6f6bupycd7c158e-1314199310.tcb.qcloud.la/image/shoucangyes%20.png"
        })
      } else {
        console.log("shoucang请求失败", res)
        shoucang = false
        this.setData({
          imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png"
        })
      }
    })
  wx.cloud.database().collection('article')
    .doc(this.data.mid)
    .get()
    .then(res => {
      console.log("添加成功", res)
      this.setData({
        image2:res.data.level2,
        image3:res.data.level3,
        ['detail[0].title']: res.data.question1,
        ['detail[1].title']: res.data.question2,
        ['detail[2].title']: res.data.question3,
        ['detail[3].title']: res.data.question4,
        ['detail[0].answer']: res.data.answer1,
        ['detail[1].answer']: res.data.answer2,
        ['detail[2].answer']: res.data.answer3,
        ['detail[3].answer']: res.data.answer4,
        ['detail[0].array[0].name']: res.data.option1_1,
        ['detail[0].array[1].name']: res.data.option1_2,
        ['detail[0].array[2].name']: res.data.option1_3,
        ['detail[0].array[3].name']: res.data.option1_4,
        ['detail[1].array[0].name']: res.data.option2_1,
        ['detail[1].array[1].name']: res.data.option2_2,
        ['detail[1].array[2].name']: res.data.option2_3,
        ['detail[1].array[3].name']: res.data.option2_4,
        ['detail[2].array[0].name']: res.data.option3_1,
        ['detail[2].array[1].name']: res.data.option3_2,
        ['detail[2].array[2].name']: res.data.option3_3,
        ['detail[2].array[3].name']: res.data.option3_4,
        ['detail[3].array[0].name']: res.data.option4_1,
        ['detail[3].array[1].name']: res.data.option4_2,
        ['detail[3].array[2].name']: res.data.option4_3,
        ['detail[3].array[3].name']: res.data.option4_4,
        ['wordlist[0].word']: res.data.word1,
        ['wordlist[1].word']: res.data.word2,
        ['wordlist[2].word']: res.data.word3,
        ['wordlist[3].word']: res.data.word4,
        ['wordlist[4].word']: res.data.word5,
        ['wordlist[5].word']: res.data.word6,
        ['wordlist[6].word']: res.data.word7,
      })
    })
    .catch(err => {
      console.log("请求失败", err)
    })
  console.log(this.data)
},
//改变收藏状态
clickme() {
  if (shoucang == false) {
    this.setData({
      imageurl: "https://7461-tan-ran-mian-dui-6f6bupycd7c158e-1314199310.tcb.qcloud.la/image/shoucangyes%20.png"
    })
    wx.cloud.database().collection('shoucang')
      .add({
        data: {
          id: this.data.mid,
          level: this.data.mid1,
          ming: this.data.mid2,
          skill: this.data.mid3,
          imagepath: this.data.mid4,
          name: this.data.mid5,
          location: this.data.mid6,
        }
      })
    wx.showToast({
      title: '已收藏', //标题
      icon: "success", //图标类型, 默认success
      duration: 1500 //提示框停留时间, 默认1500ms
    })
  } else {
    this.setData({
      imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
    })
    wx.cloud.database().collection('shoucang')
      .where({
        id: this.data.mid
      })
      .remove()
    wx.showToast({
      title: '已取消', //标题
      icon: "success", //图标类型, 默认success
      duration: 1500 //提示框停留时间, 默认1500ms
    })
  }
  shoucang = !shoucang
},
  //获取当前滑块的index
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
  },
  //点击切换，滑块index赋值
 
  onShareAppMessage: function () {
    return {
      title: this.data.mid2 + "个人信息"
    }
  },
  tel: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.mid5,
    })
  },
  previous: function (e) {
    this.setData({
      number: this.data.number - 1,
      curring: this.data.curring - 1,
    })
  },
  radioChange: function (e) {
    let index = e.currentTarget.dataset.index
    let id = e.currentTarget.dataset.id
    let detail = this.data.detail
    for (let i = 0; i < detail.length; i++) {
      if (detail[i].id == id) {
        detail[i].array[index].usname = true
        for (let j = 0; j < detail[i].array.length; j++) {
          if (j != index) {
            detail[i].array[j].usname = false
          }
        }
      }
    }
    this.setData({
      detail: detail
    })
  },
  nextstep: function (e) {
    let detail = this.data.detail
    let number = this.data.number
    let curring = this.data.curring
    let usname = 0;
    for (let i = 0; i < detail[number].array.length; i++) {
      if (!detail[number].array[i].usname) {
        usname++
      }
    }
    if (usname == detail[number].array.length) {
      wx.showToast({
        title: '答题选项不能为空',
        icon: 'none',
        duration: 2000
      })
      return false;
    }
    curring++
    number++
    if (curring > 3) {
      curring = -1
    }
    this.setData({
      curring: curring,
      number: number,
    })
  },
  subsic: function (e) {
    let detail = this.data.detail
    let answer = 0
    let letter = ''
    for (let i = 0; i < detail.length; i++) {
      for (let j = 0; j < detail[i].array.length; j++) {
        if (detail[i].array[j].usname) {
          letter = detail[i].answer - 1
          if (letter == j) {
            answer++
          }
        }
      }
    }
    wx.showToast({
      title: '答对了:' + answer + '题',
      icon: 'none',
      duration: 2000
    })
  },
  notebook(event) {
    wx.showModal({
      title: "是否加入notebook",
      success(res) {
        if (res.confirm == true) {
          wx.cloud.database().collection('notebook')
            .where({
              word: event.currentTarget.dataset.word,
            })
            .get()
            .then(reg => {
              if (reg.data != 0) {
                wx.showToast({
                  title: '已收藏', //标题
                  icon: "success", //图标类型, 默认success
                  duration: 1500 //提示框停留时间, 默认1500ms
                })
              } else {
                wx.cloud.database().collection('notebook')
                .add({
                  data:{
                    word: event.currentTarget.dataset.word
                  }
                })
                
              }
            })
        }
      }
    })
  },
})