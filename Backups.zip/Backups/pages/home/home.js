let db = wx.cloud.database()
let _ = db.command
Page({
  data: {
    article: [],
    key: null
  },

  onLoad() {
    db.collection('article')
      .orderBy("_id",'asc')
      .get()
      .then(res => {
        this.setData({
          article: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  getKey(e) {
    this.setData({
      key: e.detail.value
    })
    if (this.data.key == '') {
      db.collection('article')
        .get()
        .then(res => {
          this.setData({
            article: res.data
          })
        })
        .catch(err => {
          console.log("请求失败", err)
        })
    }
  },
  Search() {
    if (!this.data.key) {
      wx.showToast({
        icon: 'error',
        title: '请输入内容',
      })
    }
    if (this.data.key) {
      db.collection('article')
        .where(_.or([{
            location: db.RegExp({
              regexp: this.data.key,
              options: 'i'
            })
          },
          {
            ming: db.RegExp({
              regexp: this.data.key,
              options: 'i'
            })
          },
          {
            name: db.RegExp({
              regexp: this.data.key,
              options: 'i'
            })
          }
        ]))
        .get()
        .then(res => {
          this.setData({
            article: res.data
          })
        })
        .catch(err => {
          console.log("请求失败", err)
        })
    }
  },
  f1: function (event) {
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_3 = event.currentTarget.dataset.id_3
    var id_4 = event.currentTarget.dataset.id_4
    var id_5 = event.currentTarget.dataset.id_5
    var id_6 = event.currentTarget.dataset.id_6
    var id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: "/article/article?id_1=" + id_1 + "&id_2=" + id_2 + "&id=" + id + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6 + "&id_3=" + id_3,
    })
  }
})