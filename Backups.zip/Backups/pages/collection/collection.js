//shoucang
var app = getApp();
Page({
  data: {
    color1: '#056aee',
    currentData: 0,
    list: [],
    list1: [],
  },
  checkCurrent1: function (e) {
    this.setData({
      color1: '#056aee'
    });
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  checkCurrent2: function (e) {
    this.setData({
      color1: '#FF8247'
    });
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },
  onLoad() {
    wx.cloud.database().collection('shoucang')
      .where({
        Nickname: app.globalData.user.Nickname,
      })
      .get()
      .then(res => {
        this.setData({
          list: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
    wx.cloud.database().collection('shoucanglis1')
      .where({
        Nickname: app.globalData.user.Nickname,
      })
      .get()
      .then(res => {
        this.setData({
          list1: res.data
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
  },
  f1: function (event) {
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_3 = event.currentTarget.dataset.id_3
    var id_4 = event.currentTarget.dataset.id_4
    var id_5 = event.currentTarget.dataset.id_5
    var id_6 = event.currentTarget.dataset.id_6
    var id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: "/article/article?id=" + id + "&id_1=" + id_1 + "&id_2=" + id_2 + "&id_3=" + id_3 + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6,
    })
  },
  f2: function (event) {
    var id_1 = event.currentTarget.dataset.id_1
    var id_2 = event.currentTarget.dataset.id_2
    var id_3 = event.currentTarget.dataset.id_3
    var id_4 = event.currentTarget.dataset.id_4
    var id_5 = event.currentTarget.dataset.id_5
    var id_6 = event.currentTarget.dataset.id_6
    var id_7 = event.currentTarget.dataset.id_7
    var id_8 = event.currentTarget.dataset.id_8
    var id_9 = event.currentTarget.dataset.id_9
    if (id_9 == "0") {
      wx.navigateTo({
        url: "/listen_part/listen_part?id_1=" + id_1 + "&id_2=" + id_2 + "&id_3=" + id_3 + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6 + "&id_7=" + id_7 + "&id_8=" + id_8 + "&id_9=" + id_9,
      })
    } else {
      wx.navigateTo({
        url: "/listen_part2/listen_part2?id_1=" + id_1 + "&id_2=" + id_2 + "&id_3=" + id_3 + "&id_4=" + id_4 + "&id_5=" + id_5 + "&id_6=" + id_6 + "&id_7=" + id_7 + "&id_8=" + id_8 + "&id_9=" + id_9,
      })
    }
  },

  ok() {
    wx.showToast({
      title: '提交成功'
    })
  },
  //获取当前滑块的index
  bindchange: function (e) {
    const that = this;
    that.setData({
      currentData: e.detail.current
    })
  },
  //点击切换，滑块index赋值
  checkCurrent: function (e) {
    const that = this;
    if (that.data.currentData === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentData: e.target.dataset.current
      })
    }
  },


})