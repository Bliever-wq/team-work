let shoucang = false
var app = getApp();
Page({
  data: {
    imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
    currentData: 0,
    curring: -1,
    mid3:'',
    number: 0,
    answer: 0,
  },
  onLoad: function (options) {
    this.setData({
      mid1: options.id_1,
      mid2: options.id_2,
      mid4: options.id_4,
      mid5: options.id_5,
      mid6: options.id_6,
      mid7: options.id_7,
      mid8: options.id_8,
      mid9: options.id_9,
      imageurl: "",
    })
    if (this.data.mid8 == 0)
      wx.cloud.database().collection('speech')
      .doc(this.data.mid1)
      .get()
      .then(res => {
        this.setData({
          mid3:res.data.skill
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
    else
      wx.cloud.database().collection('news')
      .doc(this.data.mid1)
      .get()
      .then(res => {
        this.setData({
          mid3:res.data.skill
        })
      })
      .catch(err => {
        console.log("请求失败", err)
      })
    wx.cloud.database().collection('shoucanglis1') //判断是否在听力收藏里面
      .where({
        Nickname: app.globalData.user.Nickname,
        id: this.data.mid1
      })
      .get()
      .then(res => {
        if (res.data != 0) {
          shoucang = true
          this.setData({
            imageurl: "https://7461-tan-ran-mian-dui-6f6bupycd7c158e-1314199310.tcb.qcloud.la/image/shoucangyes%20.png"
          })
        } else {
          console.log("shoucang请求失败", res)
          shoucang = false
          this.setData({
            imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png"
          })
        }
      })
  },
  clickme() {
    if (shoucang == false) {
      this.setData({
        imageurl: "https://7461-tan-ran-mian-dui-6f6bupycd7c158e-1314199310.tcb.qcloud.la/image/shoucangyes%20.png"
      })
      wx.cloud.database().collection('shoucanglis1')
        .add({
          data: {
            Nickname: app.globalData.user.Nickname,
            id: this.data.mid1,
            location: this.data.mid2,
            skill: this.data.mid3,
            imagepath: this.data.mid4,
            name: this.data.mid5,
            idname: this.data.mid6,
            music: this.data.mid7,
            flag: this.data.mid8,
            judge: this.data.mid9
          }
        })
      wx.showToast({
        title: '已收藏', //标题
        icon: "success", //图标类型, 默认success
        duration: 1500 //提示框停留时间, 默认1500ms
      })
    } else {
      this.setData({
        imageurl: "https://i.imgtg.com/2022/11/23/4hNAF.png",
      })
      wx.cloud.database().collection('shoucanglis1')
        .where({
          Nickname: app.globalData.user.Nickname,
          id: this.data.mid1
        })
        .remove()
      wx.showToast({
        title: '已取消', //标题
        icon: "success", //图标类型, 默认success
        duration: 1500 //提示框停留时间, 默认1500ms
      })
    }
    shoucang = !shoucang
  },
})