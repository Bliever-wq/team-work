Page({
  data: {
    user: '',
    yes: false,
    toforgive: false,
    tobackup: false,
    user_note: "",
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    canIUseOpenData: false
  },

  onShow: function () {
    let user = wx.getStorageSync('user')

    this.setData({
      user: user
    })
  },

  onLoad() {
    let user = wx.getStorageSync('user')
    console.log("进入index界面获取缓存", user)
    this.setData({
      user: user
    })
  },
  //授权登录
  login() {
    wx.navigateTo({
      url: '/login/login',
    })
  },

  loginOut() {
    this.setData({
      user: ''
    })
    wx.setStorageSync('user', null)
  },

  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  voteTitle: function (e) {
    if (e.detail.value < 500 && e.value > 0)
      this.setData({
        day_task: e.detail.value
      })
    wx.setStorage({
      key: 'day_task',
      data: e.detail.value,
    })
  },
  my_collect() {
    wx.navigateTo({
      url: '../collect_card/collect_card',
    })
  },
  suggestion() {
    wx.navigateTo({
      url: '../suggestion/suggestion',
    })
  },
  notebook() {
    wx.navigateTo({
      url: '../notebook/notebook',
    })
  },
  collection() {
    wx.navigateTo({
      url: '../collection/collection',
    })
  },
  history() {
    wx.navigateTo({
      url: '../history/history',
    })
  },
  about_me() {
    wx.navigateTo({
      url: '../about1/about1',
    })
  },
  my_word_list() {
    wx.navigateTo({
      url: '../myword/myword',
    })
  },
})