var app = getApp();
Page({
  data: {
    color1: '#1691f5',
    list: []
  },

  onLoad(options) {
    wx.cloud.database().collection('notebook')
      .where({
        Nickname: app.globalData.user.Nickname,
      })
      .get()
      .then(res => {
        this.setData({
          list: res.data
        })
      })
      .catch(res => {
        console.log("请求失败", res)
      })
  },
  delete(event) {
    wx.showModal({
      title: "是否移出notebook",
      success(res) {
        if (res.confirm == true) {
          wx.cloud.database().collection('notebook')
            .doc(event.currentTarget.dataset.id)
            .remove()
        }
      }
    })
  },
})